# Eggs > 2023-01-30 9:11pm
https://universe.roboflow.com/eggs-ujxja/eggs-cobw3

Provided by a Roboflow user
License: CC BY 4.0

